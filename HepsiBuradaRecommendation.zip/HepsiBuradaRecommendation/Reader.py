import zipfile
import json
import pandas as pd


def ReadData():

    with zipfile.ZipFile('Data.zip', 'r') as z:
        for filename in z.namelist():
            if (filename.startswith("data")):

                try:
                    extendedMetaFile = filename + "meta.json"
                    extendedEventFile = filename + "events.json"

                    with z.open(extendedMetaFile) as df:

                        Meta_Data = json.load(df,encoding = "utf-8")
                    Meta = pd.DataFrame(Meta_Data['meta'])
                    Meta = Meta.dropna()

                    with z.open(extendedEventFile) as df:
                        Event_Data = json.load(df,encoding = "utf-8")
                    Events = pd.DataFrame(Event_Data['events'])
                    Events = Events.dropna()

                except:
                    print("Datas were read")

    return Meta, Events