from Reader import *
from ProcessData import *
from Models import *
from flask import Flask,request,jsonify
from flask_cors import CORS


Meta, Events = ReadData()
Meta = MakeUpperText(Meta)
CombinedData = PhraseData(Meta)
Transformed = TransformedData(CombinedData,Meta)


app = Flask(__name__)
CORS(app)

@app.route('/events', methods=['GET'])
def Recommended_Products():

    SessionId = request.args.get('sessionid')
    CardList = FindProductsWithRelatedSessionId(SessionId, Events)
    RecommendData = RecommendedProducts(CardList, Meta, CombinedData, Transformed)
    recommendation_dict = RecommendData.to_dict("records")

    return jsonify(recommendation_dict)

if __name__=='__main__':
    app.run(host='0.0.0.0')

