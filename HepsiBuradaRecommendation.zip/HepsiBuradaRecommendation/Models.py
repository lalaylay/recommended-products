import pandas as pd
import scipy.sparse as sp
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def TransformedData(data_phrase, data):
    object_count = CountVectorizer()
    count_matrix = object_count.fit_transform(data['name'])

    tfidf = TfidfVectorizer()
    tfidf_matrix = tfidf.fit_transform(data_phrase['phrase'])

    phrase_sparse = sp.hstack([count_matrix, tfidf_matrix], format='csr')
    cosine_sim = cosine_similarity(phrase_sparse, phrase_sparse)

    return cosine_sim

def RecommendedProducts(cardlist, data, combine, transform):

    newlist = list(dict.fromkeys(cardlist))
    simScoresForAllProducts = list()
    for i in range(len(newlist)):

        try:
            indices = pd.Series(data.index, index=data['productid'])
            # print(indices['HBV00000NVZE8'])
            # print(cardlist[i])
            index = indices[newlist[i]]

            sim_scores = list(enumerate(transform[index]))
            sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
            sim_scores = sim_scores[1:11]

            for i in range(len(sim_scores)):
                simScoresForAllProducts.append(sim_scores[i])
        except:
            print("Product has no brand")

    simScoresForAllProducts.sort()
    print(simScoresForAllProducts)

    product_indices = [i[0] for i in simScoresForAllProducts[1:11]]

    product_id = data['productid'].iloc[product_indices]
    product_brand = data['brand'].iloc[product_indices]
    product_category = data['category'].iloc[product_indices]
    product_subcategory = data['subcategory'].iloc[product_indices]
    product_name = data['name'].iloc[product_indices]

    recommendation_data = pd.DataFrame(columns=['productid', 'brand', 'category', 'subcategory', 'name'])

    recommendation_data['productid'] = product_id
    recommendation_data['brand'] = product_brand
    recommendation_data['category'] = product_category
    recommendation_data['subcategory'] = product_subcategory
    recommendation_data['name'] = product_name

    return recommendation_data