

def MakeUpperText(df):
    df['brand'] = df['brand'].str.upper()
    df['category'] = df['category'].str.upper()
    df['subcategory'] = df['subcategory'].str.upper()
    df['name'] = df['name'].str.upper()
    df = df.replace(',', '', regex=True)

    return df

def PhraseData(data):
    data_phrase = data.drop(columns=['productid'])
    data_phrase['phrase'] = data_phrase[data_phrase.columns[0:4]].apply(lambda x: ','.join(x.dropna().astype(str)),
                                                                        axis=1)
    data_phrase = data_phrase.drop(columns=['name', 'subcategory', 'brand', 'category'])

    return data_phrase

def FindProductsWithRelatedSessionId(sessionId,dataFrame):

    itemsList = []
    CardItemsId = []
    values = dataFrame.loc[dataFrame["sessionid"] == sessionId]
    itemsList.append(list(values["productid"]))
    for i in range(len(itemsList[0])):
        CardItemsId.append(itemsList[0][i])

    return CardItemsId

